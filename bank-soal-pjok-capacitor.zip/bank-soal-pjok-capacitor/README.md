# Bank Soal PJOK - SDN 238 Cigondewah (Android)

Aplikasi pengelola bank soal PJOK (dasbor, bank soal, input/edit, rakit paket, riwayat).
Semua data disimpan di HP (localStorage), tidak butuh Google Apps Script/Sheets/Docs.

## Membuka di Android Studio
Syarat: Node.js 18+ (atau 20), Android Studio.

    npm install
    npx cap add android
    npx cap sync android
    npx cap open android

Di Android Studio: tunggu Gradle sync selesai, pilih HP/emulator, tekan Run.
Untuk APK: Build > Build Bundle(s) / APK(s) > Build APK(s).
Untuk Play Store: Build > Generate Signed Bundle / APK, dan ganti appId di capacitor.config.json.

Setiap kali mengubah www/index.html, jalankan `npx cap sync android` lagi.

## Catatan
- 60 soal contoh awal (ID PJOK-0001 dst.) otomatis terisi saat pertama dibuka. Bisa diedit/dihapus.
- Paket soal dibuka di dalam aplikasi (bukan Google Docs); tombol "Salin teks" untuk menempel ke Word/WhatsApp.
- Tampilan memakai Tailwind dari CDN, jadi perlu internet saat aplikasi dibuka.
- Data hilang bila "Hapus data aplikasi" dilakukan atau aplikasi di-uninstall.
- Opsional tanpa Android Studio: unggah folder ini ke GitHub, workflow di .github membuat APK debug otomatis.
